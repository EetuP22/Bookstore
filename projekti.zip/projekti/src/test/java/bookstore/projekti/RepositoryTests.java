package bookstore.projekti;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;

import bookstore.domain.AppUser;
import bookstore.domain.AppUserRepository;
import bookstore.domain.Book;
import bookstore.domain.BookRepository;
import bookstore.domain.Category;
import bookstore.domain.CategoryRepository;

import java.math.BigDecimal;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.ANY)
public class RepositoryTests {

    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private AppUserRepository appUserRepository;

    @Autowired
    PasswordEncoder passwordEncoder;

    @Test
    public void testCreateAndFindBook() {
        Category category = new Category("Test Category");
        category = categoryRepository.save(category);

        Book book = new Book("Test Book", "Test Author", 2021, "1234567890123", new BigDecimal("19.99"), category);
        book = bookRepository.save(book);

        List<Book> books = bookRepository.findByTitleContainingIgnoreCase("Test Book");
        assertThat(books).hasSize(1);
        assertThat(books.get(0).getTitle()).isEqualTo("Test Book");
    }

    @Test
    public void testDeleteBook() {
        Category category = new Category("Test Category");
        category = categoryRepository.save(category);

        Book book = new Book("Test Book", "Test Author", 2021, "1234567890123", new BigDecimal("19.99"), category);
        book = bookRepository.save(book);

        bookRepository.delete(book);
        assertThat(bookRepository.findById(book.getId())).isEmpty();
    }

    @Test
    public void testCreateAndFindCategory() {
        Category category = new Category("Test Category");
        category = categoryRepository.save(category);

        List<Category> categories = (List<Category>) categoryRepository.findAll();
        assertThat(categories).hasSize(1);
        assertThat(categories.get(0).getName()).isEqualTo("Test Category");
    }

    @Test
    public void testCreateAndFindAppUser() {
        AppUser user = new AppUser("testuser", passwordEncoder.encode("password"), "USER");
        user = appUserRepository.save(user);
    
        AppUser foundUser = appUserRepository.findByUsername("testuser");
        assertThat(foundUser).isNotNull();
        assertThat(foundUser.getUsername()).isEqualTo("testuser");
    }

    @Test
    public void testDeleteAppUser() {
        AppUser user = new AppUser("testuser", "password", "USER");
        user = appUserRepository.save(user);

        appUserRepository.delete(user);
        assertThat(appUserRepository.findByUsername("testuser")).isNull();
    }
}